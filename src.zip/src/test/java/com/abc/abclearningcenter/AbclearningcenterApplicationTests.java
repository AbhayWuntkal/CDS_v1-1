package com.abc.abclearningcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbclearningcenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
