package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Profiletype_mst;


public interface CorporateProfiletypeMstRepository extends JpaRepository<Profiletype_mst, Integer>  {

}
