package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Companybranch;


public interface CorporateCompanyBranchRepository extends JpaRepository<Companybranch, Integer> {

}
