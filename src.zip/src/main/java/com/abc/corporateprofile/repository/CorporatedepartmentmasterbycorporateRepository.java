package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Department_Master_by_Corporate;



public interface CorporatedepartmentmasterbycorporateRepository extends JpaRepository<Department_Master_by_Corporate, Integer> {

}
