package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Gst_State_mst;


public interface CorporateGststateMstRepository extends JpaRepository<Gst_State_mst, Integer> {

}
