package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.lnk_user_role;


public interface CorporateLnkuserRoleRepository extends JpaRepository<lnk_user_role, Integer> {

}
