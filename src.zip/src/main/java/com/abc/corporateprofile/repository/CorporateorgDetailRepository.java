package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Organizational_Details;

public interface CorporateorgDetailRepository extends JpaRepository<Organizational_Details, Integer> {

}
