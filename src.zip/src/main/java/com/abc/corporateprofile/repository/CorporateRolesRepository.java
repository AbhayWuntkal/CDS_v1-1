package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Roles;

public interface CorporateRolesRepository extends JpaRepository<Roles, Integer>{

}
