package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Gender_mst;

public interface CorporateGenderMstRepository extends JpaRepository<Gender_mst, Integer> {

}
