package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Addresstype_mst;

public interface CorporateAddresstypeMstRepository  extends JpaRepository<Addresstype_mst, Integer> {

}
