package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Documenttype_mst;


public interface CorporatedocumenttypeMstRepository extends JpaRepository<Documenttype_mst, Integer> {

}
