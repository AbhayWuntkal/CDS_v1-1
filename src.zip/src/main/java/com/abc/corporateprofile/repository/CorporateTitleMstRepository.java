package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Title_mst;

public interface CorporateTitleMstRepository extends JpaRepository<Title_mst, Integer> {

}
