package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Bank_mst;

public interface CorporateBankMstRepository extends JpaRepository<Bank_mst, Integer> {

}
