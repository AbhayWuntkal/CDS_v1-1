package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Userstaus_mst;

public interface CorporateUserstausMstRepository extends JpaRepository<Userstaus_mst, Integer>{

}
