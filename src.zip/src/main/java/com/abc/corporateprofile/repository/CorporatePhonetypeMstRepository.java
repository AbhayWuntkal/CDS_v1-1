package com.abc.corporateprofile.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.corporateprofile.dto.Phonetype_mst;

public interface CorporatePhonetypeMstRepository extends JpaRepository<Phonetype_mst, Integer> {

}
